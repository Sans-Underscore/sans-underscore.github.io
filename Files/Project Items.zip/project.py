# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
import os.path
import numpy as np
import PIL
import PIL.ImageDraw

print('The crimson knight comes from “Crimson Knight.” Go to Wiki Main Page, ftbwiki.org/Crimson_Knight.')

#Open the hallway in numpy
directory = os.path.dirname(os.path.abspath(__file__))  
filepath_jack = os.path.join(directory, 'IMG_3292.jpg')
jack_nicholson_numpy = plt.imread(filepath_jack)

#Open the knight in numpy
filepath_rob = os.path.join(directory, 'download_4.jpg')
rob_numpy = plt.imread(filepath_rob)


# Converts both numpy pictures to PIL
rob_image_pil = PIL.Image.fromarray(rob_numpy)

jack_image_pil = PIL.Image.fromarray(jack_nicholson_numpy)





# Places knight in hallway
jack_image_pil.paste(rob_image_pil,(1800,2500))



#converts hall (with knight included) back to numpy

jack_numpy = np.array(jack_image_pil)


#makes visible windows blue if they are brighter than 400
for r in range(2173,2559):
    for c in range(364,662):
        if sum(jack_numpy[r][c])>400:
            jack_numpy[r][c] = [0,0,255]
for r in range(2132,2444):
    for c in range(832,996):
        if sum(jack_numpy[r][c])>450:
            jack_numpy[r][c] = [0,0,255]
            
#Displays the image in its final form.

fig, ax = plt.subplots(1, 1)
ax.imshow(jack_numpy, interpolation='none')
fig.show()